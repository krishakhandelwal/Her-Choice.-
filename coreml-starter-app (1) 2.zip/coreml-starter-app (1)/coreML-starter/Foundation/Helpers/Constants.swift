//
//  Constants.swift
//  Constants
//
//  
//

import Foundation
import SwiftUI

struct Constants {
    static let imgDim = 200.0 // scale down image size for storing on cloudkit
}
