//
//  Map.swift
//  coreML-starter
//
//  Created by Scholar on 6/30/22.
//

import Foundation
import SwiftUI


struct Map: View {
    
  var body: some View {
    Image("Map")
          .resizable()
          .scaledToFit()
      
  }// body
}// View
