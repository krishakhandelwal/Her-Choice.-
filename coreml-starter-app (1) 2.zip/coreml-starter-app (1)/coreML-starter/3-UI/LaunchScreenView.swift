//
//  LaunchScreenView.swift
//  coreML-starter
//
//  
//

import SwiftUI

struct LaunchScreenView: View {
    var body: some View {
        VStack {
            VStack {
                // header image:
                // TODO: replace with your own image.  Drag an image from your computer to assets.xcassets and add the name of your image below
                Image("circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 250)
                // image from: https://www.pngitem.com/middle/ioRbwwh_what-is-water-footprint-safe-water-save-life/
                
                // title
                // TODO: Replace app title
                Text("HER CHOICE.")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundColor(.black)
                
                Divider().frame(maxWidth: 300)
                
                // info
                // TODO: Replace with description of your app
                VStack(spacing: 20) {
                    Text("Discover if abortion is legal in your state, find helpful organizations, donation links, and other resources")
                    
                    Text("The purpose of this app is to educate anyone who wants to learn more about current abortion laws.")
                    
                    Text("Gather the state flags to get started!")
                }
                .padding()
                .multilineTextAlignment(.center)
                
                // item list
                // TODO: replace with the names of your items
                HStack(spacing: 10) {
                    VStack {
                        Text("🗽")
                        Text("NY")
                    }
                    .padding()
                    
                    VStack {
                        Text("🌧")
                        Text("WA")
                    }
                    .padding()
                    
                    VStack {
                        Text("🤠")
                        Text("TX")
                    }
                    .padding()
                    
                    VStack {
                        Text("☀️")
                        Text("UT")
                    }
                    .padding()
                    
                    VStack {
                        Text("🏔")
                        Text("WY")
                    }
                    .padding()
                    
                    VStack {
                        Text("🆔")
                        Text("ID")
                    }
                    .padding()
                }
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(10)
                .padding()
                
                // start button
                HStack {
                          NavigationLink(destination: ClassificationView()){
                            Text("Start")
                          }
                          .buttonStyle(RoundedRectButtonStyle())
                          .padding()
                          NavigationLink(destination: Map()){
                            Text("Map")
                          }
                }
                .buttonStyle(RoundedRectButtonStyle())
                .padding()
                
                // byline
                // TODO: Add your names
                Text("Krisha, Finley, Naomi")
                    .font(.caption)
                    .padding()
            }
            .padding()
            .frame(maxWidth: 500)
            .background(Color.white)
            .cornerRadius(25)
            .shadow(radius: 5)
            
        }// VStack
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(hex: 0xD5F4FF, opacity: 1.0))
        .edgesIgnoringSafeArea(.all)
        .navigationBarHidden(true)
    }
}

struct LaunchScreenView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            if #available(iOS 15.0, *) {
                LaunchScreenView()
                    .previewDevice(PreviewDevice(rawValue: "iPad Pro (12.9-inch)"))
                    .previewInterfaceOrientation(.landscapeLeft)
            } else {
                // Fallback on earlier versions
            }
        }
    }
}
