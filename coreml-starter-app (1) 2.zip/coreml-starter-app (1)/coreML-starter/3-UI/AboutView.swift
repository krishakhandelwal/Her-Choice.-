//
//  AboutView.swift
//  coreML-starter
//
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        VStack {
            Text("About the Creators")
                .font(.title)
            Text("Here's some info about the creators of the app!")
        }
        
        VStack {
            Text("Krisha")
                .font(.title)
            Text("Krisha is a rising junior in high school. She's really passionate about coding & computer science, and she is an advocate for women's rights & gender equality.")
            Text("Finley")
                .font(.title)
            Text("Finley is a rising junior at Holy Names Academy. She is very passionate about human rights and is very interested in learning to code.")
            Text("Naomi")
                .font(.title)
            Text("Naomi is a rising sophomore at Tesla Stem and is an amazing steminist who slays all code.")
        }
        .padding()
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
